package firstAutomation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FirstTestCase {
	
	public static void main(String[] args){
		
		
		//Creating WebDriver instance
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\ASUS\\Desktop\\Testing Training\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		driver.get("https://google.com");

	}
	


}
